package com.example.scrapooo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
