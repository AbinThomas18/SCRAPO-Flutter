import 'package:flutter/material.dart';

class PopUpMenuModel {
  String title;
  IconData icon;

  PopUpMenuModel(this.title, this.icon);
}
