package com.example.bechdal_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
