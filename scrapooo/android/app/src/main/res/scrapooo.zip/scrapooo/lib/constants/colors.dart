import 'package:flutter/material.dart';

Color primaryColor = const Color(0xffA088D5);
Color secondaryColor = const Color(0xff6b37e5);
Color whiteColor = Colors.white;
Color blackColor = Colors.black;
Color? greyColor = Colors.grey[800];
Color disabledColor = Colors.grey;
Color errorColor = Colors.red;
Color linkColor = Color.fromARGB(255, 6, 97, 172);
